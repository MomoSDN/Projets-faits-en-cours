<?php
include_once('header_membre.php');

// Connexion à la BDD pour récupérer mes planètes
$afficheplanete = $bdd->prepare("SELECT * FROM dbplanetes p
                                    WHERE p.p_id = :pla_id");
$afficheplanete->execute([
    "pla_id" => $_GET["id"]
]);

// Je récupère ma planète
$dbplanetes = $afficheplanete->fetch();
// si il y a une erreur, on retourne sur la page principale
if(!$dbplanetes){
    header('Location: Site.php');
    die;
}

// <?= <===> <?php echo
?>
<!-- liste avec les informations de la planète remplie avec ses infos -->
<h1><?= $dbplanetes['nom'] ?></h1>
<ul>
    <li>Nom : <?= $dbplanetes['nom'] ?></li>
    <li>Type de la planète : <?= $dbplanetes['types'] ?></li>
    <li>Masse de la planète : <?= $dbplanetes['masse'] ?></li>
    <li>diamètre de la planète : <?= $dbplanetes['diametre'] ?></li>
    <li>distance de la planète du soleil : <?= $dbplanetes['distance_soleil'] ?></li>
    <li>Période d'obite : <?= $dbplanetes['periode_orbite'] ?></li>
    <li>Description de la planète : <?= $dbplanetes['contenu']?></li>
    <li>Image de la planète : <a href ="">lien image</a></li>
</ul></li>
</ul>
<!-- bouton redirigeant vers la page de modification de la planète -->
<div>
    <a href="modifier_article_membre.php?id=<?= $_GET['id']?>" class="btn-btn-primary">Modifier la planète</a>
    <a class= "btn btn-primary" href ="Site.php">Retour au menu</a>
</div>
<?php
include_once 'footer.php';
?>
