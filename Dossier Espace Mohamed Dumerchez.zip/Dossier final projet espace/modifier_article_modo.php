<?php
include_once('header_modo.php');
// recupérer l'id de la planète que l'on va modifier et enregistrer ces valeurs 
if(isset($_GET['id']) and !empty($_GET['id'])){
        $getid = $_GET['id'];
        $personne_co = $_SESSION["pseudo"];
    $recupArticle = $bdd->prepare('SELECT * from dbplanetes where p_id = ?');
    $recupArticle->execute(array($getid));
    // si la requête trouve une planète correspondant à l'id trouvé, les valeurs sont enregistrées
    if($recupArticle->rowCount()> 0){
        $infoarticle = $recupArticle->fetch();
        $nom = $infoarticle["nom"];
        $diametre = $infoarticle["diametre"];
        $masse = $infoarticle["masse"];
        $distancesoleil = $infoarticle["distance_soleil"];
        $periodeorbite = $infoarticle["periode_orbite"];
        $contenu = $infoarticle["contenu"];
        $auteur = $infoarticle["auteur"];
        $type = $infoarticle["types"];

        if(isset($_POST['envoi'])){
             // ces valeurs sont les valeurs prises dans le formulaire que l'on va utiliser pour la requête update suivante
        $nom_saisi = htmlspecialchars($_POST["Nom"]);
        $diametre_saisi = htmlspecialchars($_POST["Diametre"]);
        $masse_saisi = htmlspecialchars($_POST["Masse"]);
        $distance_saisi = htmlspecialchars($_POST["Distance_soleil"]);
        $periode_saisi = htmlspecialchars($_POST["periode_orbite"]);
        $contenu_saisi = htmlspecialchars($_POST["contenu"]);
        $type_saisi = htmlspecialchars($_POST["type"]);
        $update_article = $bdd->prepare('UPDATE dbplanetes set nom = ?, diametre = ?, masse = ?, distance_soleil = ?, periode_orbite = ?, contenu = ?, types = ? WHERE p_id = ?');
        $update_article->execute(array($nom_saisi,$diametre_saisi,$masse_saisi,$distance_saisi,$periode_saisi,$contenu_saisi,$type_saisi,$getid));
        header('Location: articles.php');}

    

    }else{
        echo "pas d'articles";}

}else{
    echo "Aucun identifiant trouvé";
}
?>
<!-- form comprenant la valeur enregistrée de la planète (avant la requête update) -->
<!doctype html>
<html>
<head>
<title>Modifier un article</title>
<meta charset='utf-8'>
</head>
<body>
<div class="row">
<h1>Modifier une planète</h1>
<form action="" method="POST">
    <div class="mb-3">
        <label for="Nom" class="form-label">Nom</label>
        <input type="text" class="form-control" id="Nom" name="Nom" value="<?= $nom ?>">
    </div>
    <br>
    <div class="mb-3">
    <div>
        <input type="radio" id="type" name="type" value="Tellurique">
        <label for="type" class="form-label">Tellurique</label>
    </div>

    <div>
        <input type="radio" id="type" name="type" value="Gazeuse">
        <label for="type" class="form-label">Gazeuse</label>
    </div>

    <div>
        <input type="radio" id="type" name="type" value="Autre">
        <label for="type" class="form-label">Autre</label>
    </div>
    <br>
    <div class="mb-3">
        <label for="Diametre" class="form-label">diamètre</label>
        <input type="text" class="form-control" id="Diametre" name="Diametre"  value="<?= $diametre ?>">
    </div>
    <div class="mb-3">
        <label for="Masse" class="form-label">Masse</label>
        <input type="text" class="form-control" id="Masse" name="Masse"  value="<?= $masse ?>">
    </div>
    <div class="mb-3">
        <label for="Distance_soleil" class="form-label">Distance par rapport au soleil</label>
        <input type="text" class="form-control" id="Distance_soleil" name="Distance_soleil" value="<?= $distancesoleil ?>">
    </div>
    <div class="mb-3">
        <label for="periode_orbite" class="form-label">Période en orbite autour du soleil</label>
        <input type="text" class="form-control" id="periode_orbite" name="periode_orbite" value="<?= $periodeorbite ?>">
    </div>
    <div class="mb-3">
        <label for="contenu" class="form-label">contenu</label>
        <textarea type="text" name="contenu"><?= $contenu ?></textarea>
    </div>
    <input type="submit" class="btn btn-primary" name="envoi">  
    <!-- retour au menu -->
    <a class="btn btn-primary" href="Liste Moderation.php">Retourner au menu</a>      
</form>
</body>