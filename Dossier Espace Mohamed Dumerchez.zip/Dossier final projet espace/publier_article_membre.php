<!-- connection à la BDD, sécurité et redirection si vous ne vous êtes pas connecté -->
<?php
include_once('header_membre.php');
?>
<?php
// la requête s'active si le bouton est utilisé
if(isset($_POST['envoi'])){
    // si le contenu et le nom est rempli la condition est activée
    if(!empty($_POST['Nom']) and !empty($_POST['contenu'])){
        $Nom = htmlspecialchars($_POST["Nom"]);
        $Diametre = htmlspecialchars($_POST["Diametre"]);
        $Masse = htmlspecialchars($_POST["Masse"]);
        $Distance = htmlspecialchars($_POST["Distance_soleil"]);
        $Orbite = htmlspecialchars($_POST["periode_orbite"]);
        $contenu = nl2br(htmlspecialchars($_POST['contenu']));
        $auteur = htmlspecialchars($_POST["auteur"]);
        $types = htmlspecialchars($_POST["type"]);
        // requête qui rentre la nouvelle planète dans la base de donnée à l'aide d'un formulaire 
        $inserer_article= $bdd->prepare('INSERT INTO dbplanetes(nom,diametre,masse,distance_soleil,periode_orbite,contenu,auteur,types)VALUES(?,?,?,?,?,?,?,?)');
        $inserer_article->execute(array($Nom,$Diametre,$Masse,$Distance,$Orbite,$contenu,$auteur,$types));
        header('Location: Site.php');
    }else{
        echo "Veuillez remplir tous les champs...";
    }
}
?>
<!doctype html>
<html>
<head>
<title>Publier un article</title>
<meta charset='utf-8'>
</head>
<body>
<!-- Si le pseudo est mal écrit (mauvaise majuscule) l'article ne pourra être modifié par l'utilisateur (excepté par un admin ou modo) -->
<div style ="color:red">"Attention à bien écrite ton pseudo ! Sinon la modification ne sera pas possible."</div>
<br>
    </div>  
    <div class="row">
    <!-- form pour créer une planète ou un "article" -->
<h1>Ajouter une planète</h1>
<br>
<form action="" method="POST">
<br>
    <div class="mb-3">
        <label for="auteur" class="form-label">Auteur</label>
        <input type="text" class="form-control" id="auteur" name="auteur">
    </div>
    <div class="mb-3">
        <label for="Nom" class="form-label">Nom</label>
        <input type="text" class="form-control" id="Nom" name="Nom">
    </div>
    <br>
    <div class="mb-3">
    <div>
        <input type="radio" id="type" name="type" value="Tellurique">
        <label for="type" class="form-label">Tellurique</label>
    </div>

    <div>
        <input type="radio" id="type" name="type" value="Gazeuse">
        <label for="type" class="form-label">Gazeuse</label>
    </div>

    <div>
        <input type="radio" id="type" name="type" value="Autre">
        <label for="type" class="form-label">Autre</label>
    </div>
    <br>
    <div class="mb-3">
        <label for="diametre" class="form-label">diamètre</label>
        <input type="text" class="form-control" id="diametre" name="Diametre">
    </div>
    <div class="mb-3">
        <label for="masse" class="form-label">Masse</label>
        <input type="text" class="form-control" id="masse" name="Masse">
    </div>
    <div class="mb-3">
        <label for="distance_soleil" class="form-label">Distance par rapport au soleil</label>
        <input type="text" class="form-control" id="disantce_soleil" name="Distance_soleil">
    </div>
    <div class="mb-3">
        <label for="periode_orbite" class="form-label">Période en orbite autour du soleil</label>
        <input type="text" class="form-control" id="periode_orbite" name="periode_orbite">
    </div>
    <label for="contenu" class="form-label">Faits sur la planète</label>
    <div class="mb-3">
        <textarea type ="text" name = "contenu" cols="100" rows="5"></textarea>
    </div>
    <br>
    <br>
    <input type="submit" class="btn btn-primary" name="envoi">
    <!-- bouton de retour -->
    <a class="btn btn-primary" href="Site.php">Retourner au menu</a>      
</form>
</body>