<?php
include_once('header_admin.php');
// recupération de l'id de l'utilisateur à effacer avec une requête préparée
if(isset($_GET['id']) and !empty($_GET['id'])){
    $getid = $_GET['id'];
    $recupUser = $bdd->prepare('SELECT * FROM utilisateur WHERE uti_id = ?');
    $recupUser->execute(array($getid));
    if($recupUser->rowCount() > 0){
        //si on trouve un utilisateur avec cet id, la condition s'active et execute la requête préparée delete 
        $bannirUser = $bdd->prepare('DELETE FROM utilisateur WHERE uti_id=?');
        $bannirUser->execute(array($getid));
        header('Location: membres.php');

    }else{
        echo "Pas de membre";
    }
}else{
    echo "L'identifiant n'a pas été récupéré";
}
?>
