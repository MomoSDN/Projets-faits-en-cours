<?php
// connection bdd + sécurité
include_once('header_modo.php');
// condition activée si le bouton est utilisé
    if(isset($_POST['envoi'])){
        // vérificqtion que le pseudo rentré est bien dans la base de donnée
        if(!empty($_POST['pseudo']) and !empty($_POST['message'])){
            $pseudo = htmlspecialchars($_POST["pseudo"]);
            $message = nl2br(htmlspecialchars($_POST['message']));
            $recupUser = $bdd->prepare('SELECT * FROM utilisateur WHERE uti_pseudo = ?');
        $recupUser->execute(array($pseudo));
        if($recupUser ->rowCount() > 0){
        $_SESSION['pseudo'] = $pseudo;
        // insère le message rentré dans une table message
        $insererMessage= $bdd->prepare('INSERT INTO messages(pseudo,messagem)VALUES(?,?)');
            $insererMessage->execute(array($pseudo,$message));
    }else{
        echo "mauvais pseudo";
    }
            
        }else{
            echo "Veuillez remplir tous les champs...";
        }
    }
    ?>
<!-- form avec le pseudo et le message que l'on veut envoyer -->
<!doctype html>
<html>
<head>
    <title>Chatroom</title>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
    <form method="POST" action="">

        <input type="text" name="pseudo" autocomplete="off">
        <br><br>
        <textarea type ="text" name = "message"></textarea>
        <br>
        <input type="submit" name="envoi">
    </form>
<section id="messages"></section>
<!-- script initialisant le programme qui affiche les messages en direct -->
<script>
    setInterval('load_messages()',500);
    function load_messages(){
        $('#messages').load('load_chat.php');
    }
</script>
</body>
</html>