<?php
// première page à ouvrir (début du site)
// connection à la BDD pas besoin de la sécurité car sinon cela fait une boucle ou on ne peut pas se connecter
session_start();
try {
    $bdd = new PDO(
        'mysql:host=localhost;dbname=planete;charset:utf8',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
}catch(Exception $e){
    die('Erreur : '.$e->getMessage());
}
// la condition pour pouvoir vérifier si le mot de passe et le pseudo correspond à un membre si le bouton est utilisé
if(isset($_POST['envoi'])){
    // récupère le pseudo et le mdp mis en post
    if(!empty($_POST["pseudo"]) and !empty($_POST["mdp"])){
        $pseudo = htmlspecialchars($_POST['pseudo']);
        $mdp = htmlspecialchars($_POST['mdp']);
        // requête qui vérifie le statut d'admin et la présence du membre dans la base de donnée
        $recupUser = $bdd->prepare('SELECT * FROM utilisateur WHERE uti_pseudo = ?');
        $recupUser->execute(array($pseudo));
        
        // Si on trouve une ligne avec cette description l'utilisateur est connecté et redirigé et les valeurs de seesions sont attribuées
        if($recupUser ->rowCount() > 0){
            foreach($recupUser->fetchAll() as $user){
                if(password_verify($_POST['mdp'],$user['uti_mdp'])){
                    $_SESSION['id'] = $user['uti_id'];
                    $_SESSION['pseudo'] = $pseudo;
                    $_SESSION['mdp'] = $mdp;
                    header('Location: Site.php');
                die;
                }
                
                
            }    
    }
    }else{
        echo "mpd ou pseudo incorrect";
    }
}
?>
<!doctype html>
<html>
<head>
    <title>Connection</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- form avec le pseudo et le mdp ainsi que le bouton pour l'inscription et connection-->
    <form class="form" method="POST" action="">
        <b class="ecriture">Votre pseudo</b>
        <br>
        <input type="text" name="pseudo" autocomplete="off"></input>
        <br>
        <b class="ecriture">Votre mot de passe</b><br>
        <input type="password" name="mdp" autocomplete="off"></input>
        <br>
        <br>
        <input class="boi" type="submit" name="envoi" autocomplete="off" placeholder="Connection"></input>
    </form>
    <a class= "btn btn-primary" href ="inscription.php">Inscription</a>
    <!-- redirection vers les ifférentes pages de connections pour les admins et modos-->
    <a class= "btn btn-primary" href ="Connection_admin.php">Vous êtes un admin ?</a>
    <a class= "btn btn-primary" href ="connection_modo.php">Vous êtes un modo ?</a>
</body>
<footer></footer>
</html>