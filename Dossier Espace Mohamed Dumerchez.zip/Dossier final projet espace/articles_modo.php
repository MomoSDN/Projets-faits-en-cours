<?php
// header version admin avec sécurité plus connection BDD
include_once('header_modo.php');
?>
<!doctype html>
<html>
<head>
<title>Afficher tous les articles</title>
<meta charset='utf-8'>
</head>
<body>
<?php
// barre de recherche en récupérant la valeur dans un form
$recherche = htmlspecialchars($_GET['s']);
// requête pour pouvoir afficher les planètes par leurs nom
$allplanets = $bdd->query('SELECT * FROM dbplanetes ORDER BY p_id ASC');
if(isset($_GET['s']) AND !empty($_GET['s'])){
    $recherche = htmlspecialchars($_GET['s']);
    $allplanets = $bdd->query('SELECT * FROM dbplanetes WHERE nom LIKE "%'.$recherche.'%" ORDER BY p_id ASC');
    
}
?>
<?php
// header version admin avec sécurité plus connection BDD
include_once('header_modo.php');
?>
<!doctype html>
<html>
<head>
<title>Afficher tous les articles</title>
<meta charset='utf-8'>
<link rel="stylesheet" href="style.css">
</head>
<body>
<?php
// barre de recherche en récupérant la valeur dans un form
$recherche = htmlspecialchars($_GET['s']);
// requête pour pouvoir afficher les planètes par leurs nom
$allplanets = $bdd->query('SELECT * FROM dbplanetes ORDER BY p_id ASC');
if(isset($_GET['s']) AND !empty($_GET['s'])){
    $recherche = htmlspecialchars($_GET['s']);
    $allplanets = $bdd->query('SELECT * FROM dbplanetes WHERE nom LIKE "%'.$recherche.'%" ORDER BY p_id ASC');
    
}
?>
    <!DOCTYPE html>
<html>
<head>
    <title>Recherche des planètes et auteurs</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- form qui récupère le nom de pla planète -->
    <form method="GET">
        <input type="search" name="s" placeholder="rechercher une planète" autocomplete="off">
        <input type="submit" name="envoyer">
    </form>
    <section class="afficher_utilisateur">
        <?php
        // condition qui vérifie si la valeur existe
        if($allplanets->rowCount()>0){
            while($planete = $allplanets->fetch()){?>
                <p><?='<a href="modifier_article_modo.php?id='.$planete['p_id'].'">Voir Planete</a>'; ?></p>
                <?php
            }
        }else{
            ?>
            <p>Aucune planète ou trouvée</p>
            <?php
        }
        ?>
    </section>
    <?php 
    // tableau avec les différents articles crées par tous le monde
    $recupArticles = $bdd->query('SELECT * FROM dbplanetes');
    While($article = $recupArticles->fetch()){
        ?>
        <div class="article" style="border: 1px solid black">
            <h1><?= $article["nom"];?></h1>
            <br>
            <p><?= $article["contenu"];?></p>
            <a href="supprimer_article.php?id=<?=$article['p_id'];?>">
            <button style="color:white; background-color:red; margin-bottom: 10px">Supprimer l'article</button>
            </a> 
            <a href="modifier_article_modo.php?id=<?=$article['p_id'];?>">
            <button style="color:black; background-color:yellow; margin-bottom: 10px">Modifier l'article</button>
            </a>   
        </div>
        <?php
        
        
    }
    ?>
    <br>
    <br>
    <!-- redirection vers le menu de modération-->
    <a class="btn btn-primary" href="Liste Moderation.php" name="envoi">Retourner au menu</a> 
</body>
</html> 