<?php
if(!$_SESSION['mdp']){
    header('Location: connection_membre.php');
}
?>
</body>
</html>