<?php
// connection BDD + sécurité
include_once("header_modo.php");
?>
<!doctype html>
<html>
<head>
<title>Home</title>
<meta charset='utf-8'>
</head>
<!--  différents lien qui redirige vers les fonctions du modérateur -->
<body>
    <a class= "btn btn-primary" href="publier_article_modo.php">Publier un article</a>
    <a class= "btn btn-primary" href="articles_modo.php?s=terre">Afficher tous les articles</a>
    <a class= "btn btn-primary" href="lobby_chat.php">Parler avec les utilisateurs</a>
    <a class= "btn btn-primary" href ="me_déconnecter_modo.php">Me déconnecter</a>
</body>