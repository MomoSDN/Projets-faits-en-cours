<!-- Header et sécurité + connection à BDD -->
<?php
try {
    $bdd = new PDO(
        'mysql:host=localhost;dbname=planete;charset:utf8',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
}catch(Exception $e){
    die('Erreur : '.$e->getMessage());
}
if(!$_SESSION['mdp']){
    header('Location: articles.php');
}
if(isset($_GET['id']) and !empty($_GET['id'])){
    $getid = $_GET['id'];
    // requête select avec l'id correspodant au getid
    $recupArticle = $bdd->prepare('SELECT * from dbplanetes where p_id = ?');
    $recupArticle->execute(array($getid));
    // requête delete pour la planète trouvée avec l'id du GET
    if($recupArticle->rowCount()> 0){
        $deletearticle = $bdd->prepare('DELETE FROM dbplanetes WHERE p_id=?');
        $deletearticle->execute(array($getid));
    }else{
        echo "pas d'articles";
    }
}else{
    echo "aucun id";
}
?>