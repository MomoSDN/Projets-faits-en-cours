<?php
    include_once('header_membre.php');

    // Requête qui récupère les données des planètes
    $planete = $bdd->query("SELECT p_id,nom,types,masse,diametre,distance_soleil,periode_orbite FROM dbplanetes");
?>
<!-- voici les différents liens qui indiquent les fonctions du site -->
<div>
    <a class="btn btn-primary" href="publier_article_membre.php">Ajouter une planète</a>
    <a class= "btn btn-primary" href ="déconnection_membre.php">Me déconnecter</a>
    <a class= "btn btn-primary" href ="lobby_chat.php">Chatroom</a>
    <a class= "btn btn-primary" href ="recherche_planète.php">Recherche par planète</a>
    <?='<a class= "btn btn-primary" href ="profil.php?id='.$_SESSION['id'].'">Voir/éditer profile</a>'?>
</div>
<?php
// requête concernant la barre de recherche par auteur d'articles
$allauteur = $bdd->query('SELECT * FROM dbplanetes ORDER BY p_id ASC');
if(isset($_GET['f']) AND !empty($_GET['f'])){
    $recherches = htmlspecialchars($_GET['f']);
    $allauteur= $bdd->query('SELECT * FROM dbplanetes WHERE auteur LIKE "%'.$recherches.'%" ORDER BY p_id ASC');
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Recherche des planètes et auteurs</title>
    <meta charset="utf-8">
</head>
<body>
    <!-- form comprenant la barre de recherche -->
    <form method="GET">
        <input type="search" name="f" placeholder="rechercher vos articles avec votre nom" autocomplete="off">
        <input type="submit" name="envoyer">
    </form>
    <!-- fonction pour pouvoir afficher les fiches planètes correspondantes -->
    <section class="afficher_utilisateur">
        <?php
        if($allauteur->rowCount()>0){
            while($planetes = $allauteur->fetch()){?>
                <p><?='<a href="planetes.php?id='.$planetes['p_id'].'">Voir Article</a>'." ".$planetes['nom']; ?></p>
                <?php
            }
        }else{
            ?>
            <p>Aucune article trouvé</p>
            <?php
        }
        ?>
    </section>
       <!-- La table comprenant un résumé des planètes -->
<table class="table table-striped">
    <thead>
    <tr>
        <th>Nom</th>
        <th>Type</th>
        <th>masse</th>
        <th>diamètre</th>
        <th>distance du soleil</th>
        <th>periode d'orbite</th>
        <th>Fiche planète<th>
    </tr>
    </thead>
    <tbody>
    <?php
        // Je parcours les résultats de la requête ligne par ligne
        while ($dbplanetes = $planete->fetch()){
            echo('<tr><td>'.$dbplanetes['nom'].'<td>'.$dbplanetes['types'].'<td>'.$dbplanetes['masse'].'<td>'.$dbplanetes['diametre'].'<td>'.$dbplanetes['distance_soleil'].'<td>'.$dbplanetes['periode_orbite'].'</td><td><a href="planetes.php?id='.$dbplanetes['p_id'].'">Voir planete</a></td></tr>');
        }

    ?>
    </tbody>
</table>
<footer></footer>
<!-- balise html et body -->
<?php
    include_once('footer.php');
?>
