<?php
// connection bdd et sécurité
session_start();
try {
    $bdd = new PDO(
        'mysql:host=localhost;dbname=planete;charset:utf8',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
}catch(Exception $e){
    die('Erreur : '.$e->getMessage());
}
if(!$_SESSION['mdp']){
    header('Location: connection_membre.php');
}
?>
<!-- lien bootstrap pour les listes et tableaux -->
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>