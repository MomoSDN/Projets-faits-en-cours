<?php
// connection BDD + sécurité
include_once("header_admin.php");
?>
<!--  différents lien qui redirige vers les fonctions de l'admin -->
<!doctype html>
<html>
<head>
<title>Home</title>
<meta charset='utf-8'>
</head>
<body>
    <a class= "btn btn-primary" href="membres.php"> Afficher tous les memebres</a>
    <a class= "btn btn-primary" href="publier_article_admin.php">Publier un article</a>
    <a class= "btn btn-primary" href="articles.php?s=terre">Afficher tous les articles</a>
    <a class= "btn btn-primary" href="lobby_chat.php">Parler avec les utilisateurs</a>
    <a class= "btn btn-primary" href ="me_déconnecter_admin.php">Me déconnecter</a>
</body>
</html>