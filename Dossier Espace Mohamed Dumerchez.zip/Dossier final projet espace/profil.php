<?php
// connection BDD + sécurité
include_once('header_membre.php');
// récuperation de l'id de l'utilisateur par l'url
if(isset($_GET['id']) and !empty($_GET['id'])){
        $getid = $_GET['id'];
    // requête préparée pour récupérer les valeurs de l'utilisateur par l'id récupéré
    $recupArticle = $bdd->prepare('SELECT * from utilisateur where uti_id = ?');
    $recupArticle->execute(array($getid));
    // si la condition est atteinte, les variables auront comme valeur celles de l'utilisateur
    if($recupArticle->rowCount()> 0){
        $infoarticle = $recupArticle->fetch();
        $nom = $infoarticle["uti_nom"];
        $mdp = $infoarticle['uti_mdp'];
        $prenom = $infoarticle['uti_prenom'];
        $rang = $infoarticle['uti_rang'];
        $pseudo = $infoarticle['uti_pseudo'];
    }
}
?>
<!-- lste contenant les valaeurs enregistrées dans les variables -->
<!doctype html>
<html>
<head>
<title>Votre Profil</title>
<meta charset='utf-8'>
</head>
<body>
<div class="row">
<h1>Votre Profil</h1>
<ul>
    <li>Votre nom : <?= $nom ?></li>
    <li>Votre prénom: <?= $prenom ?></li>
    <li>Votre pseudo : <?= $pseudo ?></li>
    <li>Votre rang : <?= $rang ?></li>
<!-- bouton redirigeant vers le menu d'édition du profil -->
    <?='<a class= "btn btn-primary" href ="editionprofile.php?id='.$_SESSION['id'].'">Voir/éditer profile</a>'?>
    <a class= "btn btn-primary" href ="Site.php">Retour au menu</a>
</ul>
</ul>
</body>
</head>
</html>