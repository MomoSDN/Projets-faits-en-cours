<?php
// revoir vidéo
try {
    $bdd = new PDO(
        'mysql:host=localhost;dbname=planete;charset:utf8',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
}catch(Exception $e){
    die('Erreur : '.$e->getMessage());
}

$recupMessages = $bdd->query('SELECT * FROM messages');
while($message = $recupMessages->fetch()){
    ?>
    <div class="message">
        <h4><?= $message['pseudo']; ?></h4>
        <p><?= $message['messagem']; ?></p>
    </div>
    <?php
}

?>