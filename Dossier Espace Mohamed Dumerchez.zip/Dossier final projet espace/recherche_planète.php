<?php
    include_once('header_membre.php');
?>
<?php
// requête concernant la barre de recherche par auteur d'articles
$allplanets = $bdd->query('SELECT * FROM dbplanetes ORDER BY p_id ASC');
if(isset($_GET['s']) AND !empty($_GET['s'])){
    $recherche = htmlspecialchars($_GET['s']);
    $allplanets = $bdd->query('SELECT * FROM dbplanetes WHERE nom LIKE "%'.$recherche.'%" ORDER BY p_id ASC');  
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Recherche des planètes et auteurs</title>
    <meta charset="utf-8">
</head>
<body>
    <!-- form comprenant la barre de recherche -->
    <form method="GET">
        <input type="search" name="s" placeholder="rechercher une planète" autocomplete="off">
        <input type="submit" name="envoyer">
    </form>
    <section class="afficher_utilisateur">
        <!-- fonction pour pouvoir afficher les fiches planètes correspondantes -->
        <?php
        if($allplanets->rowCount()>0){
            while($planete = $allplanets->fetch()){?>
                <p><?='<a href="planetes.php?id='.$planete['p_id'].'">Voir Planete</a>'; ?></p>
                <?php
            }
        }else{
            ?>
            <p>Aucune planète trouvée</p>
            <?php
        }
        ?>
        <!-- bouton de retour au menu -->
        <a class= "btn btn-primary" href ="Site.php">Retour au menu</a>
    </section>
    <!-- balise html et body -->
<?php
    include_once('footer.php');
?>
</body>
</html>