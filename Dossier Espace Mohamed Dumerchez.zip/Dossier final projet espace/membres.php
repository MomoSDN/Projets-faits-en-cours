<?php
// connection BDD + sécurité
include_once('header_admin.php');
?>
<!doctype html>
<html>
<head>
    <title>Afficher les membres</title>
    <meta charset="utf-8">
</head>
<body>
    <!-- requête query pour selectionner toutes les données d'un utilisateur -->
        <?php
        $recupUsers = $bdd->query('SELECT * FROM utilisateur');
        // tant que la boucle est active, des paragraphe avec les nom des membres et le bouton pour bannir le membre
        while($user = $recupUsers->fetch()){
            ?>
            <p><?= $user['uti_pseudo'];?><br><a href="bannir.php?id=<?=$user['uti_id'];?>" style="color:red;text-decoration : none;">Bannir le membre</a></p>
            <?php
        }
        ?>
        <!-- retour au menu -->
        <a class="btn btn-primary" href="Liste Administration.php">Retourner au menu</a>   
</body>
</html>