<?php session_start();
// condition pour empecher d'acceder à la page de connection par cette page
if(!$_SESSION['mdp']){
    header('Location: connection_modo.php');
}
    $_SESSION = array();
    // destruction de la session pour reinitialiser les valeurs de session puis un redirection
    session_destroy();?>
    <a href ="connection_modo.php">Me reconnecter</a>