<?php
// sécurité plus connection
include_once('header_membre.php');
// condition récupérant l'id du profil que l'on va afficher  et le pseudo de la personne connecté
if(isset($_GET['id']) and !empty($_GET['id'])){
        $getid = $_GET['id'];
        $personne_co = $_SESSION["pseudo"];
// requête qui récupèrel'uutlisateur correspondant à l'id récupéré
    $recupArticle = $bdd->prepare('SELECT * from utilisateur where uti_id = ?');
    $recupArticle->execute(array($getid));
// si on trouve une ligne ou cette condition est remplie on enregistre les valeurs de la requête dans des variables
    if($recupArticle->rowCount()> 0){
        $infoarticle = $recupArticle->fetch();
        $nom = $infoarticle["uti_nom"];
        $prenom = $infoarticle["uti_prenom"];
        $pseudo = $infoarticle["uti_pseudo"];
        $mdp = password_hash($infoarticle["uti_mdp"],PASSWORD_DEFAULT);

        if(isset($_POST['envoi'])){
// récupération des valeurs données dans le form en-dessous
            $nom_saisi = htmlspecialchars($_POST["Nom"]);
            $prenom_saisi = htmlspecialchars($_POST["Prenom"]);
            $pseudo_saisi = htmlspecialchars($_POST["Pseudo"]);
            $mdp_saisi = password_hash(htmlspecialchars($_POST["Mdp"]),PASSWORD_DEFAULT);
// requête update qui permet de pouvoir changer les valeurs des utilisateurs par les variables entrées dans le form
            $update_article = $bdd->prepare('UPDATE utilisateur set uti_nom = ?, uti_prenom = ?, uti_pseudo = ?, uti_mdp = ? WHERE uti_id = ?');
            $update_article->execute(array($nom_saisi,$prenom_saisi,$pseudo_saisi,$mdp_saisi,$getid));
            header('Location: Site.php');}    
        }else{
                echo "pas d'articles";}
        
        }else{
            echo "Aucun identifiant trouvé";
        }
?>
<!doctype html>
<html>
<head>
<title>Modifier votre profil</title>
<meta charset='utf-8'>
</head>
<body>
<div class="row">
<h1>Modifier votre profil</h1>
<!-- form qui permet de changer les variables de la base de donnée remplie avec les valeurs précédentes -->
<form action="" method="POST">
    <div class="mb-3">
        <label for="Nom" class="form-label">Nom</label>
        <input type="text" class="form-control" id="Nom" name="Nom" value="<?= $nom ?>">
    </div>
    <div class="mb-3">
        <label for="Prenom" class="form-label">Prénom</label>
        <input type="text" class="form-control" id="Prenom" name="Prenom"  value="<?= $prenom ?>">
    </div>
    <div class="mb-3">
        <label for="Pseudo" class="form-label">Pseudo</label>
        <input type="text" class="form-control" id="Pseudo" name="Pseudo"  value="<?= $pseudo ?>">
    </div>
    <div class="mb-3">
        <label for="Mdp" class="form-label">Mot de passe</label>
        <input type="text" class="form-control" id="Mdp" name="Mdp" value="<?= $mdp ?>">
    </div>
    <input type="submit" class="btn btn-primary" name="envoi">  
<!-- bouton de retour au menu -->
    <a class="btn btn-primary" href="Site.php">Retourner au menu</a>      
</form>
</body>
</html>