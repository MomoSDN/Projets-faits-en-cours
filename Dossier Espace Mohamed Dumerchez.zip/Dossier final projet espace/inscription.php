<!-- session + connection BDD -->
<?php
session_start();
try {
    $bdd = new PDO(
        'mysql:host=localhost;dbname=planete;charset:utf8',
        'root',
        '',
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
}catch(Exception $e){
    die('Erreur : '.$e->getMessage());
}
// recupération des données du form dans des variables
if(isset($_POST['envoi'])){
    if(!empty($_POST["pseudo"]) and !empty($_POST["mdp"])){
        $pseudo = htmlspecialchars($_POST['pseudo']);
        $mdp = password_hash($_POST['mdp'],PASSWORD_DEFAULT);
        $prenom = htmlspecialchars($_POST['prenom']);
        $nom = htmlspecialchars($_POST['nom']);
        $rang = htmlspecialchars("Membre");
        // requête préparée insert into avec les variables rentrées dans le form
        $insertUser = $bdd->prepare('INSERT INTO utilisateur(uti_pseudo,uti_mdp,uti_prenom,uti_nom,uti_rang)VALUES(?,?,?,?,?)');
        $insertUser->execute(array($pseudo,$mdp,$prenom,$nom,$rang));
        // requête select pour vérifier que le membre s'est bien inscrit et le redirige vers le site si la condition est remplie
        $recupUser = $bdd->prepare('SELECT * FROM utilisateur WHERE uti_pseudo = ? AND uti_mdp = ?');

        $recupUser->execute(array($pseudo,$mdp));
        if($recupUser ->rowCount() > 0) {
        $_SESSION['pseudo'] = $pseudo;
        $_SESSION['mdp'] = $mdp;
        header('Location: Site.php');
    }
    }else{
        echo "veuillez remplir tous les champs";
    }
}
?>
<!-- form avec les différentes infos à rentrer pour l'inscription -->
<!doctype html>
<html>
<head>
    <title>Inscription</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css">
</head>
<body>
    <form method="POST" action="">
        <b>Votre nom</b>
        <input type="text" name="nom" autocomplete="off"></input>
        <br>
        <b>Votre prenom</b>
        <input type="text" name="prenom" autocomplete="off"></input>
        <br>
        <b>Votre pseudo</b>
        <input type="text" name="pseudo" autocomplete="off"></input>
        <br>
        <b>Votre mot de passe</b>
        <input type="password" name="mdp" autocomplete="off"></input>
        <br><br>
        <input type="submit" name="envoi" autocomplete="off" placeholder="Connection"></input>
    </form>
    <a class= "btn btn-primary" href ="connection_membre.php">Retour au menu de connection</a>
</body>
</html>

