-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 21, 2021 at 10:31 PM
-- Server version: 5.7.33
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `planete`
--
CREATE DATABASE IF NOT EXISTS `planete` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `planete`;

-- --------------------------------------------------------

--
-- Table structure for table `dbplanetes`
--

CREATE TABLE `dbplanetes` (
  `p_id` int(11) NOT NULL,
  `nom` varchar(25) NOT NULL,
  `types` text NOT NULL,
  `diametre` varchar(45) NOT NULL,
  `masse` varchar(45) NOT NULL,
  `distance_soleil` varchar(45) NOT NULL,
  `periode_orbite` varchar(45) NOT NULL,
  `contenu` text NOT NULL,
  `auteur` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dbplanetes`
--

INSERT INTO `dbplanetes` (`p_id`, `nom`, `types`, `diametre`, `masse`, `distance_soleil`, `periode_orbite`, `contenu`, `auteur`) VALUES
(7, 'terres', '', '123', '450', '4564415156', '1', 'La terre est une planÃ¨te trÃ¨s grandes par exemples.', ''),
(15, 'test', 'Gazeuse', 'test', 'test', 'test', 'test', 'test', 'CR7'),
(20, 'bvzvbzh', 'Gazeuse', '156456', '156151', '1561561', '6165165', '156116515', 'momo');

-- --------------------------------------------------------

--
-- Table structure for table `galaxie`
--

CREATE TABLE `galaxie` (
  `gal_id` int(11) NOT NULL,
  `gal_nom` varchar(25) NOT NULL,
  `gal_longueur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `pseudo` text NOT NULL,
  `messagem` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `pseudo`, `messagem`) VALUES
(12, 'Hannah', '1234'),
(13, 'Momo', 'Hey'),
(14, 'momo', 'yo<br />\r\n'),
(15, 'Snorp', 'hi'),
(16, 'momo', 'yo');

-- --------------------------------------------------------

--
-- Table structure for table `systeme_solaires`
--

CREATE TABLE `systeme_solaires` (
  `sys_id` int(11) NOT NULL,
  `sys_nom` varchar(25) DEFAULT NULL,
  `sys_annee_lumiere` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `utilisateur`
--

CREATE TABLE `utilisateur` (
  `uti_id` int(11) NOT NULL,
  `uti_nom` varchar(25) DEFAULT NULL,
  `uti_prenom` varchar(25) NOT NULL,
  `uti_pseudo` varchar(25) DEFAULT NULL,
  `uti_mdp` varchar(255) NOT NULL,
  `uti_rang` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `utilisateur`
--

INSERT INTO `utilisateur` (`uti_id`, `uti_nom`, `uti_prenom`, `uti_pseudo`, `uti_mdp`, `uti_rang`) VALUES
(15, 'tot3', 'tot3', 'tot3', '$2y$10$JeXq4.dd1F8p81h8twpbF.zczHcHYij0UwulTde4hS5Wjm5ctYmKy', 'Membre'),
(17, 'Dumerchez', 'Mohamed', 'Momo', '$2y$10$P8G.JwXtFbfoTQ9UBltOiuIYhhwyjnD4tPWbrC1hMSJLeFajK1ScK', 'admin'),
(18, 'Hannah', 'boi', 'Snorp', '$2y$10$yX2/1LEgLR4Chk/g6llJEej5IKJQr1BWoVgGkj7VasDqpGK8SCZ8q', 'modo'),
(19, 'Christiano', 'Ronaldo', 'CR7', '$2y$10$HN59Hp1QQ81OAc0ZxPK5eevgdhTEdLPYmt9Y/RPlrzvdGqDGh/bsi', 'Membre');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dbplanetes`
--
ALTER TABLE `dbplanetes`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `galaxie`
--
ALTER TABLE `galaxie`
  ADD PRIMARY KEY (`gal_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `systeme_solaires`
--
ALTER TABLE `systeme_solaires`
  ADD PRIMARY KEY (`sys_id`);

--
-- Indexes for table `utilisateur`
--
ALTER TABLE `utilisateur`
  ADD PRIMARY KEY (`uti_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dbplanetes`
--
ALTER TABLE `dbplanetes`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `utilisateur`
--
ALTER TABLE `utilisateur`
  MODIFY `uti_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
